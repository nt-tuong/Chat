import { useEffect, useRef, useState } from "react";
import EmojiTab from "./EmojiTab";
import StickerTab from "./StickerTab";
import GifTab from "./GifTab";
import PacksTab from "./PacksTab";
import { FEATURES } from "../../config/features";
import "./picker.css";

const TABS = [
  { id: "emoji", label: "Emoji", icon: "😀" },
  { id: "sticker", label: "Sticker", icon: "🧸" },
  { id: "gif", label: "GIF", icon: "🎞️" },
  { id: "packs", label: "Bộ của tôi", icon: "📁" },
];
const enabled = (t) => t.id === "emoji" || (t.id === "gif" ? FEATURES.gif : FEATURES.sticker);
const SEARCHABLE = ["emoji", "sticker", "gif"];

/**
 * Popup chọn Emoji / Sticker / GIF / quản lý bộ sticker.
 * Nút mở popup cần có thuộc tính data-picker-toggle để bấm vào nó không bị coi là "bấm ra ngoài".
 */
export default function EmojiStickerPicker({ onEmoji, onSticker, onGif, onClose }) {
  const tabs = TABS.filter(enabled);
  const [tab, setTab] = useState("emoji");
  const [query, setQuery] = useState("");
  const ref = useRef(null);
  const closeRef = useRef(onClose);
  closeRef.current = onClose;

  useEffect(() => {
    const onDown = (e) => {
      if (!ref.current?.contains(e.target) && !e.target.closest("[data-picker-toggle]")) closeRef.current();
    };
    const onKey = (e) => e.key === "Escape" && closeRef.current();
    document.addEventListener("mousedown", onDown);
    document.addEventListener("keydown", onKey);
    return () => {
      document.removeEventListener("mousedown", onDown);
      document.removeEventListener("keydown", onKey);
    };
  }, []);

  const changeTab = (id) => {
    setTab(id);
    setQuery("");
  };

  return (
    <div className="esp-pop" ref={ref} role="dialog" aria-label="Emoji và sticker">
      {SEARCHABLE.includes(tab) && (
        <div className="esp-search">
          <input
            autoFocus
            value={query}
            placeholder={`Tìm ${tab === "emoji" ? "emoji" : tab === "sticker" ? "sticker" : "GIF"}`}
            onChange={(e) => setQuery(e.target.value)}
          />
        </div>
      )}

      <div className="esp-content">
        {tab === "emoji" && <EmojiTab query={query} onPick={onEmoji} />}
        {tab === "sticker" && <StickerTab query={query} onPick={onSticker} />}
        {tab === "gif" && <GifTab query={query} onPick={onGif} />}
        {tab === "packs" && <PacksTab />}
      </div>

      <div className="esp-tabs" role="tablist" hidden={tabs.length < 2}>
        {tabs.map((t) => (
          <button
            key={t.id}
            role="tab"
            aria-selected={tab === t.id}
            className={tab === t.id ? "on" : ""}
            onClick={() => changeTab(t.id)}
          >
            <span>{t.icon}</span>
            {t.label}
          </button>
        ))}
      </div>
    </div>
  );
}
