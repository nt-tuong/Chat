import express from "express";
import http from "http";
import cors from "cors";
import { randomUUID } from "crypto";
import { Server } from "socket.io";

import { config } from "./src/config.js";
import { sessions } from "./src/auth/sessions.js";
import { createRepositories } from "./src/repositories/index.js";
import { createFileStorage } from "./src/storage/index.js";
import { createStickerService } from "./src/services/stickerService.js";
import { createEmojiService } from "./src/services/emojiService.js";
import { createApiRouter } from "./src/routes/index.js";
import { errorHandler } from "./src/middleware/errorHandler.js";

// ---- Khởi tạo các lớp: repository (DB) -> service -> route ----
const repos = createRepositories();
const storage = createFileStorage();
const services = {
  stickers: createStickerService({ repos, storage }),
  emojis: createEmojiService({ repos }),
};
if (config.features.sticker) await services.stickers.seedSystemPacks();

const app = express();
app.use(cors({ origin: config.clientOrigin }));
app.use(express.json({ limit: "50kb" }));
app.use(
  "/media",
  express.static(config.uploadsDir, {
    maxAge: "7d",
    setHeaders: (res) => res.setHeader("X-Content-Type-Options", "nosniff"),
  })
);
app.get("/", (req, res) => res.send("Server đang chạy"));
app.use("/api", createApiRouter(services));
app.use(errorHandler);

const server = http.createServer(app);
const io = new Server(server, { cors: { origin: config.clientOrigin, methods: ["GET", "POST"] } });

// ---- Chat realtime ----
const ROOMS = [
  { id: "general", name: "Cộng đồng chung" },
  { id: "dev", name: "Team Dev" },
  { id: "friends", name: "Hội bạn thân" },
];
const ALLOWED_REACTIONS = ["👍", "❤️", "😆", "😮", "😭", "😡"];
const users = new Map(); // socket.id -> username
const onlineList = () => [...new Set(users.values())];

// Chỉ nhận GIF từ GIPHY (https)
const parseGif = (g) => {
  try {
    const u = new URL(g?.url);
    if (u.protocol !== "https:" || !u.hostname.endsWith("giphy.com")) return null;
    return { url: u.href, title: String(g.title || "GIF").slice(0, 100) };
  } catch {
    return null;
  }
};

io.on("connection", (socket) => {
  socket.on("login", async (username, ack) => {
    try {
      const name = String(username || "").trim().slice(0, 20);
      if (!name) return ack?.({ ok: false, error: "Tên không được để trống" });
      if (onlineList().includes(name)) return ack?.({ ok: false, error: "Tên này đang có người dùng" });

      users.set(socket.id, name);
      ROOMS.forEach((r) => socket.join(r.id));

      const history = {};
      await Promise.all(ROOMS.map(async (r) => (history[r.id] = await repos.messages.listByRoom(r.id, 100))));

      // token dùng cho các request REST (/api/...)
      ack?.({ ok: true, token: sessions.create(name, socket.id), rooms: ROOMS, history });
      io.emit("online_users", onlineList());
    } catch (e) {
      console.error(e);
      ack?.({ ok: false, error: "Lỗi máy chủ" });
    }
  });

  // payload: { room, type: "text"|"sticker"|"gif", text | stickerId | gif:{url,title} }
  // Xử lý tuần tự theo từng socket: tin gửi liền nhau không bị đảo thứ tự
  // (tin sticker tốn thêm truy vấn nên có thể xong sau tin text gửi sau nó)
  let sendQueue = Promise.resolve();
  socket.on("send_message", (payload) => {
    sendQueue = sendQueue.then(() => handleSend(payload));
  });
  const handleSend = async (payload) => {
    try {
      const author = users.get(socket.id);
      const { room, type = "text" } = payload || {};
      if (!author || !ROOMS.some((r) => r.id === room)) return;

      const msg = { id: randomUUID(), room, author, type, text: "", sticker: null, gif: null, time: Date.now() };

      if (type === "text") {
        msg.text = String(payload.text || "").trim().slice(0, 2000);
        if (!msg.text) return;
      } else if (type === "sticker" && config.features.sticker) {
        const s = await services.stickers.resolveForSend(author, payload.stickerId);
        if (!s) return;
        msg.sticker = { id: s.id, packId: s.packId, url: s.url, animated: s.animated, name: s.name };
        await services.stickers.touchRecent(author, s.id);
      } else if (type === "gif" && config.features.gif) {
        msg.gif = parseGif(payload.gif);
        if (!msg.gif) return;
      } else return;

      io.to(room).emit("receive_message", await repos.messages.create(msg));
    } catch (e) {
      console.error(e);
    }
  };

  socket.on("react", async ({ room, messageId, emoji } = {}) => {
    try {
      const user = users.get(socket.id);
      if (!user || !ALLOWED_REACTIONS.includes(emoji)) return;
      const msg = await repos.messages.getById(messageId);
      if (!msg || msg.room !== room) return;
      const reactions = await repos.messages.toggleReaction({ messageId, userId: user, emoji });
      io.to(room).emit("message_reacted", { room, messageId, reactions });
    } catch (e) {
      console.error(e);
    }
  });

  socket.on("typing", ({ room, isTyping } = {}) => {
    const user = users.get(socket.id);
    if (!user || !ROOMS.some((r) => r.id === room)) return;
    socket.to(room).emit("typing", { room, user, isTyping: !!isTyping });
  });

  socket.on("disconnect", () => {
    sessions.dropSocket(socket.id);
    if (users.delete(socket.id)) io.emit("online_users", onlineList());
  });
});

server.listen(config.port, () => console.log(`Server chạy ở cổng ${config.port}`));
