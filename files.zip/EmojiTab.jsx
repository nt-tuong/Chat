import { useEffect, useMemo, useRef, useState } from "react";
import { emojiApi } from "../../api/chatApi";
import { normalizeText } from "../../utils/text";

function EmojiGrid({ list, onPick }) {
  return (
    <div className="esp-emoji-grid">
      {list.map((c) => (
        <button key={c} onClick={() => onPick(c)} aria-label={c}>
          {c}
        </button>
      ))}
    </div>
  );
}

export default function EmojiTab({ query, onPick }) {
  const [cats, setCats] = useState([]);
  const [recent, setRecent] = useState([]);
  const [error, setError] = useState("");
  const bodyRef = useRef(null);

  useEffect(() => {
    emojiApi.catalog().then(setCats).catch((e) => setError(e.message));
    emojiApi.recent().then(setRecent).catch(() => {});
  }, []);

  const pick = (char) => {
    onPick(char);
    setRecent((r) => [char, ...r.filter((c) => c !== char)].slice(0, 24));
    emojiApi.touch(char).catch(() => {});
  };

  const q = normalizeText(query.trim());
  const results = useMemo(
    () =>
      q
        ? cats.flatMap((c) => c.emojis).filter((e) => e.char === query.trim() || normalizeText(e.keywords).includes(q)).map((e) => e.char)
        : [],
    [q, cats, query]
  );

  const jump = (id) => bodyRef.current?.querySelector(`[data-cat="${id}"]`)?.scrollIntoView({ block: "start" });

  if (error) return <div className="esp-empty">{error}</div>;

  return (
    <>
      {!q && (
        <div className="esp-catbar">
          {recent.length > 0 && <button title="Dùng gần đây" onClick={() => jump("recent")}>🕘</button>}
          {cats.map((c) => (
            <button key={c.id} title={c.name} onClick={() => jump(c.id)}>
              {c.icon}
            </button>
          ))}
        </div>
      )}
      <div className="esp-body" ref={bodyRef}>
        {q ? (
          results.length ? <EmojiGrid list={results} onPick={pick} /> : <div className="esp-empty">Không tìm thấy emoji phù hợp</div>
        ) : (
          <>
            {recent.length > 0 && (
              <section data-cat="recent">
                <h4>Dùng gần đây</h4>
                <EmojiGrid list={recent} onPick={pick} />
              </section>
            )}
            {cats.map((c) => (
              <section key={c.id} data-cat={c.id}>
                <h4>{c.name}</h4>
                <EmojiGrid list={c.emojis.map((e) => e.char)} onPick={pick} />
              </section>
            ))}
          </>
        )}
      </div>
    </>
  );
}
