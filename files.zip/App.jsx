import { useEffect, useRef, useState } from "react";
import { socket } from "./socket";
import { setToken, mediaUrl } from "./api/http";
import EmojiStickerPicker from "./components/EmojiStickerPicker";
import "./App.css";

const REACTIONS = ["👍", "❤️", "😆", "😮", "😭", "😡"];

const colorOf = (name = "") => {
  let h = 0;
  for (const c of name) h = (h * 31 + c.charCodeAt(0)) % 360;
  return `hsl(${h} 55% 50%)`;
};
const fmtTime = (t) =>
  new Date(t).toLocaleTimeString("vi-VN", { hour: "2-digit", minute: "2-digit" });

const previewOf = (m) => (m.type === "sticker" ? "[Sticker]" : m.type === "gif" ? "[GIF]" : m.text);
// Tin chỉ có 1-3 emoji sẽ hiển thị to như Zalo
const isEmojiOnly = (t = "") => /^(?:\p{Extended_Pictographic}[\ufe0f\u200d]*){1,3}$/u.test(t.trim());

// Đăng nhập qua socket; server trả token để gọi các API REST (emoji, sticker, GIF)
const login = (name) =>
  new Promise((resolve) =>
    socket.emit("login", name, (res) => {
      if (res?.ok) setToken(res.token);
      resolve(res);
    })
  );

function Avatar({ name, size = 40, square }) {
  return (
    <div
      className={`avatar ${square ? "square" : ""}`}
      style={{ width: size, height: size, fontSize: size * 0.42, background: colorOf(name) }}
    >
      {name.trim().charAt(0).toUpperCase()}
    </div>
  );
}

/* ---------------- Màn hình đăng nhập ---------------- */
function Login({ onSubmit, error }) {
  const [name, setName] = useState("");
  return (
    <div className="login">
      <div className="login-card">
        <h1>Chat</h1>
        <p>Nhập tên để vào trò chuyện cùng mọi người</p>
        <input
          autoFocus
          maxLength={20}
          value={name}
          placeholder="Tên hiển thị"
          onChange={(e) => setName(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && onSubmit(name)}
        />
        {error && <div className="login-error">{error}</div>}
        <button disabled={!name.trim()} onClick={() => onSubmit(name)}>
          Vào chat
        </button>
      </div>
    </div>
  );
}

/* ---------------- Nội dung tin nhắn: text / sticker / gif ---------------- */
function MessageBody({ m }) {
  if (m.type === "sticker" && m.sticker)
    return <img className="sticker-img" src={mediaUrl(m.sticker.url)} alt={m.sticker.name || "Sticker"} draggable={false} />;
  if (m.type === "gif" && m.gif)
    return <img className="gif-img" src={m.gif.url} alt={m.gif.title || "GIF"} draggable={false} />;
  return <div className={`text ${isEmojiOnly(m.text) ? "big-emoji" : ""}`}>{m.text}</div>;
}

/* ---------------- Một tin nhắn ---------------- */
function Message({ m, me, showHeader, onReact }) {
  const mine = m.author === me;
  const entries = Object.entries(m.reactions || {});
  const total = entries.reduce((sum, [, users]) => sum + users.length, 0);
  const myReaction = entries.find(([, users]) => users.includes(me))?.[0];
  const tooltip = entries.map(([e, users]) => `${e} ${users.join(", ")}`).join("\n");

  return (
    <div className={`row ${mine ? "mine" : ""} ${showHeader ? "first" : ""}`}>
      {!mine &&
        (showHeader ? <Avatar name={m.author} size={36} /> : <span className="avatar-gap" />)}

      <div className="bubble-wrap">
        <div className={`bubble ${m.type === "sticker" ? "sticker" : m.type === "gif" ? "gif" : ""}`}>
          {!mine && showHeader && <div className="author">{m.author}</div>}
          <MessageBody m={m} />
          <div className="time">{fmtTime(m.time)}</div>

          {total > 0 && (
            <div className="chip" title={tooltip}>
              {entries.slice(0, 3).map(([e]) => (
                <span key={e}>{e}</span>
              ))}
              {total > 1 && <b>{total}</b>}
            </div>
          )}
        </div>

        {/* Nút thả cảm xúc: bấm = 👍 nhanh, rê chuột vào = hiện đủ 6 reaction */}
        <div className="react-zone">
          <div className="picker">
            {REACTIONS.map((e) => (
              <button
                key={e}
                className={e === myReaction ? "picked" : ""}
                onClick={() => onReact(m.id, e)}
              >
                {e}
              </button>
            ))}
          </div>
          <button
            className={`quick ${myReaction ? "active" : ""}`}
            aria-label="Thả cảm xúc"
            onClick={() => onReact(m.id, myReaction ?? "👍")}
          >
            {myReaction ?? "👍"}
          </button>
        </div>
      </div>
    </div>
  );
}

/* ---------------- Khung chat ---------------- */
function ChatPanel({ room, me, messages, online, typingUsers, onReact }) {
  const [text, setText] = useState("");
  const [showPicker, setShowPicker] = useState(false);
  const bottomRef = useRef(null);
  const inputRef = useRef(null);
  const typingRef = useRef(false);
  const timerRef = useRef(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ block: "end" });
  }, [messages.length, typingUsers.length]);

  const stopTyping = () => {
    clearTimeout(timerRef.current);
    if (typingRef.current) {
      typingRef.current = false;
      socket.emit("typing", { room: room.id, isTyping: false });
    }
  };

  const handleChange = (e) => {
    setText(e.target.value);
    if (!typingRef.current) {
      typingRef.current = true;
      socket.emit("typing", { room: room.id, isTyping: true });
    }
    clearTimeout(timerRef.current);
    timerRef.current = setTimeout(stopTyping, 1500);
  };

  const send = () => {
    if (!text.trim()) return;
    emitMessage({ type: "text", text });
    setText("");
    inputRef.current?.focus();
  };

  const emitMessage = (payload) => {
    socket.emit("send_message", { room: room.id, ...payload });
    stopTyping();
  };
  const sendSticker = (s) => emitMessage({ type: "sticker", stickerId: s.id });
  const sendGif = (g) => {
    emitMessage({ type: "gif", gif: g });
    setShowPicker(false);
  };

  const addEmoji = (e) => {
    setText((t) => t + e);
    inputRef.current?.focus();
  };

  return (
    <section className="chat">
      <header className="chat-head">
        <Avatar name={room.name} size={44} square />
        <div>
          <div className="chat-title">{room.name}</div>
          <div className="chat-sub">
            {online.length} người đang online
          </div>
        </div>
      </header>

      <div className="messages">
        {messages.length === 0 && <div className="empty">Chưa có tin nhắn. Hãy gửi lời chào đầu tiên!</div>}
        {messages.map((m, i) => (
          <Message
            key={m.id}
            m={m}
            me={me}
            showHeader={i === 0 || messages[i - 1].author !== m.author}
            onReact={(id, emoji) => onReact(room.id, id, emoji)}
          />
        ))}
        <div ref={bottomRef} />
      </div>

      <div className="typing">
        {typingUsers.length > 0 && (
          <>
            <span className="dots"><i /><i /><i /></span>
            {typingUsers.join(", ")} đang soạn tin...
          </>
        )}
      </div>

      <footer className="composer">
        {showPicker && (
          <EmojiStickerPicker
            onEmoji={addEmoji}
            onSticker={sendSticker}
            onGif={sendGif}
            onClose={() => setShowPicker(false)}
          />
        )}
        <button className="icon-btn" data-picker-toggle aria-label="Emoji và sticker" onClick={() => setShowPicker((v) => !v)}>
          😊
        </button>
        <input
          ref={inputRef}
          autoFocus
          value={text}
          placeholder={`Nhập tin nhắn tới ${room.name}`}
          onChange={handleChange}
          onKeyDown={(e) => e.key === "Enter" && send()}
        />
        <button className="send" disabled={!text.trim()} onClick={send}>
          Gửi
        </button>
      </footer>
    </section>
  );
}

/* ---------------- App ---------------- */
export default function App() {
  const [me, setMe] = useState(null);
  const [loginError, setLoginError] = useState("");
  const [rooms, setRooms] = useState([]);
  const [msgs, setMsgs] = useState({}); // { roomId: [message] }
  const [active, setActive] = useState(null);
  const [unread, setUnread] = useState({});
  const [online, setOnline] = useState([]);
  const [typing, setTyping] = useState({}); // { roomId: [username] }
  const [search, setSearch] = useState("");

  // Ref để handler socket luôn đọc được giá trị mới nhất
  const activeRef = useRef(null);
  const meRef = useRef(null);

  useEffect(() => {
    const onMessage = (m) => {
      setMsgs((p) => ({ ...p, [m.room]: [...(p[m.room] || []), m] }));
      setTyping((t) => ({ ...t, [m.room]: (t[m.room] || []).filter((u) => u !== m.author) }));
      if (m.room !== activeRef.current && m.author !== meRef.current) {
        setUnread((u) => ({ ...u, [m.room]: (u[m.room] || 0) + 1 }));
      }
    };

    const onReacted = ({ room, messageId, reactions }) =>
      setMsgs((p) => ({
        ...p,
        [room]: (p[room] || []).map((m) => (m.id === messageId ? { ...m, reactions } : m)),
      }));

    const onTyping = ({ room, user, isTyping }) =>
      setTyping((t) => {
        const others = (t[room] || []).filter((u) => u !== user);
        return { ...t, [room]: isTyping ? [...others, user] : others };
      });

    // Tự đăng nhập lại khi mất kết nối rồi nối lại (vd: restart server)
    const onReconnect = async () => {
      if (!meRef.current) return;
      const res = await login(meRef.current);
      if (res.ok) setMsgs(res.history);
    };

    socket.on("receive_message", onMessage);
    socket.on("message_reacted", onReacted);
    socket.on("typing", onTyping);
    socket.on("online_users", setOnline);
    socket.on("connect", onReconnect);

    return () => {
      socket.off("receive_message", onMessage);
      socket.off("message_reacted", onReacted);
      socket.off("typing", onTyping);
      socket.off("online_users", setOnline);
      socket.off("connect", onReconnect);
    };
  }, []);

  const selectRoom = (id) => {
    activeRef.current = id;
    setActive(id);
    setUnread((u) => ({ ...u, [id]: 0 }));
  };

  const handleLogin = async (name) => {
    setLoginError("");
    socket.connect();
    const res = await login(name.trim());
    if (!res.ok) {
      setLoginError(res.error);
      socket.disconnect();
      return;
    }
    meRef.current = name.trim();
    setMe(name.trim());
    setRooms(res.rooms);
    setMsgs(res.history);
    selectRoom(res.rooms[0].id);
  };

  const handleReact = (room, messageId, emoji) => socket.emit("react", { room, messageId, emoji });

  if (!me) return <Login onSubmit={handleLogin} error={loginError} />;

  const room = rooms.find((r) => r.id === active);
  const filtered = rooms.filter((r) => r.name.toLowerCase().includes(search.toLowerCase()));

  return (
    <div className="app">
      <nav className="rail">
        <Avatar name={me} size={48} />
        <div className="rail-btn on" title="Tin nhắn">
          <svg width="26" height="26" viewBox="0 0 24 24" fill="currentColor">
            <path d="M4 3h16a2 2 0 0 1 2 2v11a2 2 0 0 1-2 2H9l-5 4v-4H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2z" />
          </svg>
        </div>
      </nav>

      <aside className="list">
        <div className="list-top">
          <input
            placeholder="Tìm kiếm"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
        <div className="list-scroll">
          {filtered.map((r) => {
            const last = (msgs[r.id] || []).at(-1);
            return (
              <button
                key={r.id}
                className={`item ${r.id === active ? "on" : ""}`}
                onClick={() => selectRoom(r.id)}
              >
                <Avatar name={r.name} size={48} square />
                <div className="item-body">
                  <div className="item-name">{r.name}</div>
                  <div className="item-last">
                    {last ? `${last.author === me ? "Bạn" : last.author}: ${previewOf(last)}` : "Chưa có tin nhắn"}
                  </div>
                </div>
                <div className="item-meta">
                  {last && <span>{fmtTime(last.time)}</span>}
                  {unread[r.id] > 0 && <em>{unread[r.id] > 9 ? "9+" : unread[r.id]}</em>}
                </div>
              </button>
            );
          })}
        </div>
      </aside>

      {room && (
        <ChatPanel
          key={room.id}
          room={room}
          me={me}
          messages={msgs[room.id] || []}
          online={online}
          typingUsers={typing[room.id] || []}
          onReact={handleReact}
        />
      )}
    </div>
  );
}
